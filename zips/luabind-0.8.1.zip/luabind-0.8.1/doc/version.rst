.. |version| replace:: 0.8.1
